# Marine Trash Detection > 2023-03-24 5:55am
https://universe.roboflow.com/senior-project-si95y/marine-trash-detection

Provided by a Roboflow user
License: CC BY 4.0

